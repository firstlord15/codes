package org.example;

import java.sql.Timestamp;

@MyEntity
public class Dog {
    @Id
    private int id;

    @Column(value = "Ogi")
    private String name;

    @Column(value = "10")
    private int age;
}
