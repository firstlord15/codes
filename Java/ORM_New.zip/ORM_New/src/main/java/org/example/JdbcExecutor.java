package org.example;

public class JdbcExecutor {

}
