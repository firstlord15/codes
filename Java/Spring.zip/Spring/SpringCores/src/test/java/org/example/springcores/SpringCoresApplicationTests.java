package org.example.springcores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoresApplicationTests {

    @Test
    void contextLoads() {
    }

}
