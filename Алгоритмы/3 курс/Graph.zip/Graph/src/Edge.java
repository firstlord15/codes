class Edge {
    int src, dest, weight;
    Edge() { src = dest = weight = 0; }
};